# Changelog

## 3.1.0-silent-recovery
- 지속 알림과 Foreground Service 제거
- POST_NOTIFICATIONS 및 FOREGROUND_SERVICE 권한 제거
- JobScheduler Content URI trigger 기반 새 파일 감지
- 콘텐츠 변경 작업을 처리한 뒤 동일 job ID 재등록하여 감시 지속
- 최초 소스폴더 연결 시 자동 기준선 저장, 기존 파일 자동처리 방지
- 주기 복구는 마지막 기준선 이후 후보만 등록
- 앱/작업 중단 상태 자동 복구
- 저장 중 종료되어도 최종 TXT 중복 생성을 막는 idempotent 저장
- 파일 안정화 확인 후 전사 시작
- 자동 전사 1 thread, 수동 기간 전사 최대 2 thread
- Android thermal severe 이상 시 자동 대기
- 메인 UI 단순화, 설정/기록 화면 분리
- 오늘/어제/최근 3일/최근 7일/직접 날짜 기간 전사 유지/개선
