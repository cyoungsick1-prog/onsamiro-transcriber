package com.onsamiro.transcriber;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private AppConfig cfg;
    private TextView state;
    private TextView recent;
    private TextView today;
    private TextView detail;
    private Button pauseButton;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = new AppConfig(this);
        buildUi();
        // Re-arm jobs without scanning the folder. This is intentionally quiet and notification-free.
        Scheduler.reschedule(this);
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = column();
        root.setPadding(dp(20), dp(18), dp(20), dp(28));
        sv.addView(root);

        TextView title = text("온새미로 자동전사", 28, true);
        root.addView(title);
        root.addView(text("새 통화는 조용히 자동 처리하고, 놓친 구간은 다시 살아났을 때 이어서 복구합니다", 14, false));

        state = text("", 22, true);
        state.setPadding(0, dp(22), 0, dp(6));
        root.addView(state);

        detail = text("", 14, false);
        root.addView(detail);

        root.addView(section("최근 전사"));
        recent = text("", 16, false);
        root.addView(recent);

        root.addView(section("오늘"));
        today = text("", 18, true);
        root.addView(today);

        LinearLayout actions = row();
        actions.addView(weightButton("지금 확인", v -> {
            Scheduler.immediateRecovery(this, true);
            toast("새 통화와 누락 구간 확인을 요청했어요");
            refresh();
        }));
        pauseButton = weightButton("잠시 멈추기", v -> togglePause());
        actions.addView(pauseButton);
        root.addView(actions);

        root.addView(section("기간 전사"));
        root.addView(text("필요할 때만 과거 통화를 골라 전사합니다. 이미 완료된 통화는 다시 만들지 않습니다.", 13, false));

        LinearLayout quick1 = row();
        quick1.addView(weightButton("오늘", v -> startPreset(0)));
        quick1.addView(weightButton("어제", v -> startPreset(1)));
        root.addView(quick1);

        LinearLayout quick2 = row();
        quick2.addView(weightButton("최근 3일", v -> startPreset(3)));
        quick2.addView(weightButton("최근 7일", v -> startPreset(7)));
        root.addView(quick2);
        root.addView(fullButton("날짜 직접 선택", v -> pickCustomStart()));

        root.addView(section("관리"));
        LinearLayout bottom = row();
        bottom.addView(weightButton("기록 보기", v -> startActivity(new Intent(this, HistoryActivity.class))));
        bottom.addView(weightButton("설정", v -> startActivity(new Intent(this, SettingsActivity.class))));
        root.addView(bottom);

        setContentView(sv);
    }

    private void refresh() {
        if (state == null) return;
        boolean ready = cfg.basicReady(this);
        if (!ready) {
            state.setText("설정이 필요합니다");
            detail.setText("녹음폴더, TXT 저장폴더, Whisper 모델을 한 번만 설정하면 됩니다");
            recent.setText("아직 자동전사를 시작하지 않았습니다");
            today.setText("완료 0 · 대기 0 · 문제 0");
            pauseButton.setText("설정 열기");
            pauseButton.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
            return;
        }

        pauseButton.setOnClickListener(v -> togglePause());
        if (cfg.paused()) {
            state.setText("일시정지 중");
            pauseButton.setText("다시 시작");
        } else {
            state.setText("정상 작동 중");
            pauseButton.setText("잠시 멈추기");
        }

        String next = cfg.nextExpectedMs() > 0 ? fmtTime(cfg.nextExpectedMs()) : "예약 없음";
        detail.setText("지속 알림 없음 · 새 파일 감지 + " + cfg.intervalMinutes() + "분 보완복구\n"
                + "최근 확인 " + fmtTime(cfg.lastRunMs()) + " · 다음 보완 " + next
                + "\n" + cfg.lastRunNote());

        try (JobStore s = new JobStore(this)) {
            JobRecord last = s.lastCompleted();
            if (last == null) {
                recent.setText("완료된 전사가 아직 없습니다");
            } else {
                String when = fmtDateTime(last.callTimeMs);
                recent.setText(when + "\n" + last.displayName + "\n" + humanStatus(last.status));
            }

            long[] day = todayRange();
            JobStore.Stats x = s.statsBetween(day[0], day[1]);
            int problems = x.failed + x.review + x.partial;
            today.setText("완료 " + x.done + " · 대기 " + (x.waiting + x.running) + " · 문제 " + problems);
        }
    }

    private void togglePause() {
        boolean pause = !cfg.paused();
        cfg.setPaused(pause);
        if (pause) {
            Scheduler.cancelAll(this);
            try (JobStore s = new JobStore(this)) {
                s.recoverInterruptedRunning("사용자 일시정지 · 다시 시작하면 이어하기");
            }
            toast("자동전사를 잠시 멈췄어요");
        } else {
            Scheduler.reschedule(this);
            Scheduler.immediatePending(this, false);
            toast("자동전사를 다시 시작했어요");
        }
        refresh();
    }

    private void startPreset(int days) {
        long[] r = rangeForPreset(days);
        Scheduler.historical(this, r[0], r[1]);
        toast(labelForPreset(days) + " 전사를 시작했어요");
        refresh();
    }

    private void pickCustomStart() {
        Calendar now = Calendar.getInstance();
        new DatePickerDialog(this, (v, y, m, d) -> {
            Calendar start = Calendar.getInstance();
            start.set(y, m, d, 0, 0, 0);
            start.set(Calendar.MILLISECOND, 0);
            pickCustomEnd(start.getTimeInMillis());
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void pickCustomEnd(long startMs) {
        Calendar init = Calendar.getInstance();
        init.setTimeInMillis(Math.max(startMs, System.currentTimeMillis()));
        DatePickerDialog d = new DatePickerDialog(this, (v, y, m, day) -> {
            Calendar end = Calendar.getInstance();
            end.set(y, m, day, 23, 59, 59);
            end.set(Calendar.MILLISECOND, 999);
            long e = end.getTimeInMillis();
            if (e < startMs) {
                toast("종료일은 시작일보다 빠를 수 없어요");
                return;
            }
            Scheduler.historical(this, startMs, e);
            toast(fmtDate(startMs) + " ~ " + fmtDate(e) + " 전사를 시작했어요");
            refresh();
        }, init.get(Calendar.YEAR), init.get(Calendar.MONTH), init.get(Calendar.DAY_OF_MONTH));
        d.show();
    }

    private long[] rangeForPreset(int days) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long today = c.getTimeInMillis();
        if (days == 0) return new long[]{today, today + 86_400_000L - 1};
        if (days == 1) return new long[]{today - 86_400_000L, today - 1};
        return new long[]{today - (days - 1L) * 86_400_000L, System.currentTimeMillis()};
    }

    private long[] todayRange() { return rangeForPreset(0); }
    private String labelForPreset(int d) { return d == 0 ? "오늘" : d == 1 ? "어제" : "최근 " + d + "일"; }
    private String humanStatus(String s) { return Status.NO_AUDIO.equals(s) ? "음성 없음으로 확인" : "TXT 저장 완료"; }

    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private TextView section(String s) { TextView v = text(s, 20, true); v.setPadding(0, dp(22), 0, dp(6)); return v; }
    private TextView text(String s, int sp, boolean bold) { TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setPadding(0, dp(6), 0, dp(6)); if (bold) v.setTypeface(null, Typeface.BOLD); return v; }
    private Button fullButton(String s, View.OnClickListener l) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(l); return b; }
    private Button weightButton(String s, View.OnClickListener l) { Button b = fullButton(s, l); b.setLayoutParams(new LinearLayout.LayoutParams(0, dp(56), 1f)); return b; }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private String fmtTime(long ms) { return ms <= 0 ? "없음" : new SimpleDateFormat("HH:mm", Locale.KOREA).format(new Date(ms)); }
    private String fmtDateTime(long ms) { return ms <= 0 ? "시간 미확인" : new SimpleDateFormat("MM-dd HH:mm", Locale.KOREA).format(new Date(ms)); }
    private String fmtDate(long ms) { return new SimpleDateFormat("yyyy.MM.dd", Locale.KOREA).format(new Date(ms)); }
}
