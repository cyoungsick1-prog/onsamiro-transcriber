## 3.1.9-top-offset
- Move the entire main-screen stack down by 56dp to eliminate top-card clipping.
- Functional logic unchanged from v3.1.8.

# v3.1.3

- 메인 화면을 상태표시 / 실시간 전사 / 기간별 전사 / 즉시 중단 4요소로 고정
- 포괄적인 `정상 작동 중` 대신 실제 상태를 구체적으로 표시
- 기간별 전사 진행률을 메인 상태표시에 표시
- 즉시 중단 시 autoEnabled도 OFF 처리하고 force 작업도 paused를 존중
- 구간 전사 후 QC/TXT 저장 직전에 stop 재확인
- 100건 초과 기간전사는 별도 continuation job으로 이어서 처리
- 기간전사 지연 재시도는 실제 next_attempt 시각에 맞춰 예약해 불필요한 반복 폴링 방지
- 기간전사 JobScheduler를 persisted로 등록해 재부팅 복구 강화
- 실시간 전사 ON 시 OFF 동안 놓친 신규 파일을 저발열 인덱스로 1회 복구
- Settings의 중복 자동전사 토글 제거

# Changelog

## 3.1.1-indexed-recovery
- Automatic recovery now queries only recently modified audio rows through MediaStore when the selected source is on primary shared storage.
- Removed automatic 5,000-row SAF metadata traversal.
- Added one-time audio-read permission for low-heat indexed recovery.
- If indexed recovery cannot be used, automatic bulk traversal is skipped rather than heating the device.
- Persistent notification remains unused.


## 3.1.0-silent-recovery
- 지속 알림과 Foreground Service 제거
- POST_NOTIFICATIONS 및 FOREGROUND_SERVICE 권한 제거
- JobScheduler Content URI trigger 기반 새 파일 감지
- 콘텐츠 변경 작업을 처리한 뒤 동일 job ID 재등록하여 감시 지속
- 최초 소스폴더 연결 시 자동 기준선 저장, 기존 파일 자동처리 방지
- 주기 복구는 마지막 기준선 이후 후보만 등록
- 앱/작업 중단 상태 자동 복구
- 저장 중 종료되어도 최종 TXT 중복 생성을 막는 idempotent 저장
- 파일 안정화 확인 후 전사 시작
- 자동 전사 1 thread, 수동 기간 전사 최대 2 thread
- Android thermal severe 이상 시 자동 대기
- 메인 UI 단순화, 설정/기록 화면 분리
- 오늘/어제/최근 3일/최근 7일/직접 날짜 기간 전사 유지/개선

## 3.1.3-best-ui
- 메인 화면을 상태 / 실시간 전사 / 기간별 전사 / 즉시 중단 중심으로 정리
- 기간별 전사 진행률과 중단 상태를 실제 작업원장에 맞춰 표시
- 기본 Android 런처 아이콘 제거, 온새미로 전용 마이크/파형 아이콘 적용

## 3.1.4-final-icon
- 사용자 승인 온새미로 마이크/파형 런처 아이콘 적용
- v3.1.3 상태표시·실시간 전사·기간별 전사·즉시중단 구조 유지

## 3.1.5-historical-fix
- Fixed historical MediaStore files being stuck in `녹음 저장 완료 대기`.
- Added provider-aware metadata probing for MediaStore vs SAF URIs.
- Old, non-empty historical recordings now bypass per-file 5-second settle waits.
- Explicit period requests reactivate old WAIT_ORIGINAL/RETRY_WAIT jobs when metadata proves the file is settled.
- Diagnostic app version now reads the actual installed version instead of a hardcoded string.

## 3.1.6-progress-skip
- Period transcription now checks the selected TXT output folder once before loading Whisper.
- Existing transcripts are matched by the exact recording filename stem and skipped automatically.
- Supports legacy `recording.txt`, current `recording_전사.txt`, and hash-suffixed transcript names.
- Empty TXT files are not treated as completed transcripts.
- Main screen now shows overall period progress, files remaining, overall percentage, current file, stage, per-file percentage, and completed chunk count.
- Existing transcripts are counted separately and do not inflate the new-work progress denominator.
- Re-running a period does not retranscribe already completed files unless the user explicitly retries a specific item.
