from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "app/src/main/java/com/onsamiro/transcriber"
coordinator = (JAVA / "WorkCoordinator.java").read_text(encoding="utf-8")
scheduler = (JAVA / "Scheduler.java").read_text(encoding="utf-8")
service = (JAVA / "ScanJobService.java").read_text(encoding="utf-8")
model_manager = (JAVA / "ModelManager.java").read_text(encoding="utf-8")

preflight = coordinator[
    coordinator.index("private boolean preflight"):
    coordinator.index("private void processPending")
]
pending = coordinator[
    coordinator.index("private void processPending"):
    coordinator.index("private void processOne")
]
validate_existing = model_manager[
    model_manager.index("public static boolean validateExisting"):
    model_manager.index("private static String sha256")
]

assert preflight.index("RuntimeConstraints.thermalSevere(c)") < preflight.index(
    "ModelManager.validateExisting("
), "thermal check must happen before model validation"
assert "WhisperBridge.validateModel" not in validate_existing, (
    "background model validation must not load the native model"
)
assert pending.index("if (jobs.isEmpty()) break;") < pending.index(
    "new WhisperBridge(cfg.modelPath())"
), "empty scans must not load Whisper"
assert pending.index("RuntimeConstraints.thermalSevere(c)") < pending.index(
    "new WhisperBridge(cfg.modelPath())"
), "thermal check must happen before native model load"
assert "retryAfterThermal(c, forceRun || thermalRetryRequest)" in coordinator
assert "THERMAL_RETRY_ID" in scheduler and "THERMAL_RETRY_MS" in scheduler
assert 'x.putBoolean("thermal_retry", true)' in scheduler
assert 'getBoolean("thermal_retry", false)' in service
assert "setMinimumLatency(delay)" in scheduler

print("THERMAL RECOVERY STATIC REGRESSION PASS")
