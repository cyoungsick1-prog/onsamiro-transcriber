# 온새미로 자동전사 v3.1.1

Android 15+ 기준 로컬 Whisper 통화녹음 전사 앱 소스.

이번 버전의 중심은 **무알림 + 저발열 + 신규파일 우선 + 죽어도 복구 + 기간 전사**다.

- applicationId: `com.onsamiro.transcriber.v311`
- versionName: `3.1.1-indexed-recovery`
- compile/target SDK: 35
- NDK: 28.0.13004108
- CMake: 3.22.1
- ABI: arm64-v8a, x86_64
- 16 KiB page-size linker 설정 유지
- 지속 알림/Foreground Service 없음
- JobScheduler Content URI trigger + periodic recovery
- SQLite 파일/구간 작업원장
- 오늘/어제/최근 3일/최근 7일/직접 날짜 기간 전사

상세 설계는 `V310_SILENT_RECOVERY.md` 참고.
