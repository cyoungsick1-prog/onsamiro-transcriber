# v3.1.0 Silent Recovery

목표: 지속 알림 없이 새 통화를 자동 전사하고, Android가 앱 프로세스를 종료해도 다음 실행에서 누락된 통화를 복구한다.

## 핵심 동작

- Foreground Service 미사용, 지속 알림 미사용, POST_NOTIFICATIONS 권한 미사용.
- Android JobScheduler Content URI trigger로 새 파일 변경을 우선 감지한다.
- Provider가 개별 변경 URI를 주면 해당 파일 1개만 등록한다.
- Provider가 폴더 수준 변경만 알려주거나 변경 URI를 주지 않으면 마지막 자동 기준선 이후의 메타데이터만 보완 확인한다.
- 소스 폴더를 처음 선택한 시각을 자동 기준선으로 저장하여 기존 파일을 자동 신규 파일로 승격하지 않는다.
- SQLite 작업원장이 파일별 상태와 1분 구간 처리 상태를 보존한다.
- 앱/작업 중단 후 FETCHING/TRANSCRIBING/QUALITY_CHECK/SAVING 상태는 다음 실행에서 RETRY_WAIT로 복구한다.
- 최종 TXT는 source URI hash를 본문에 기록하고, 재실행 시 기존 TXT를 재확인하여 중복 저장을 방지한다.
- 전사 전 파일 크기/수정시각을 5초 간격으로 두 번 확인하여 녹음 저장이 끝난 뒤 처리한다.
- 자동 작업은 Whisper 1 thread, 사용자가 직접 요청한 기간 전사는 최대 2 thread.
- Android thermal status가 SEVERE 이상이면 10분 대기한다.
- 주기 보완 확인 기본값은 2시간이며 30분/1시간/2시간/4시간 선택 가능.
- 수동 기간 전사: 오늘/어제/최근 3일/최근 7일/직접 날짜 범위.

## 자동 복구 범위

- 앱 프로세스 종료: JobScheduler/SQLite 원장을 이용해 이어서 처리.
- 기기 재부팅/앱 업데이트: BootReceiver에서 중단 상태 복구 후 JobScheduler 재등록.
- 사용자가 Android 설정에서 강제 종료: Android 정책상 예약 작업이 중지될 수 있으므로 앱을 한 번 다시 열면 재등록된다.

## UI

메인 화면은 상태, 최근 전사, 오늘 완료/대기/문제, 지금 확인, 일시정지, 기간 전사, 기록/설정만 노출한다.
상세 폴더/모델/배터리/주기 설정과 진단정보 복사는 설정 화면으로 분리한다.
