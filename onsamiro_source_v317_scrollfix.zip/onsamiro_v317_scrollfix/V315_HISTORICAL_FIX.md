# v3.1.5 기간별 전사 대기 고착 수정

## 실제 수정
- MediaStore URI를 DocumentsContract 컬럼으로 조회하던 잘못된 원본 안정성 검사 수정.
- MediaStore URI는 OpenableColumns.SIZE + MediaStore DATE_MODIFIED로 확인하고 파일 디스크립터 길이로 보완.
- 사용자가 기간별 전사를 요청한 오래된 파일은 5초 안정화 대기를 파일마다 반복하지 않고 즉시 열기 확인 후 전사 시작.
- 이전 실행에서 WAIT_ORIGINAL/RETRY_WAIT에 남은 오래된 기간 전사 파일을 기간 전사 요청 시 DISCOVERED로 되돌려 즉시 처리 가능하게 수정.
- 진단 화면 버전 문자열 하드코딩 제거. 실제 설치 버전을 PackageManager에서 표시.

## 유지
- 실시간 전사 / 기간별 전사 / 상태 표시 / 즉시 중단 단순 UI.
- 지속 알림 없음.
- 저발열 MediaStore 인덱스 복구.
- 16KiB/NDK 28 구성.
- 승인 아이콘.
