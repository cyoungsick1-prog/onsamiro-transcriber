# v3.1.4 Final Icon

- v3.1.3 Best UI and recovery behavior retained.
- Launcher icon replaced with the user-approved Onsamiro microphone/waveform design.
- Main screen remains limited to status, realtime transcription, period transcription, and immediate stop.
- No persistent notification / no foreground service.
