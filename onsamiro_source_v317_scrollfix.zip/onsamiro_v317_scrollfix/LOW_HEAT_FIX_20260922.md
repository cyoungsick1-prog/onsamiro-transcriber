# v3.0.2 Low Heat

- 앱 화면을 여는 것만으로 JobScheduler/실시간 감시를 재등록하지 않음
- 일시정지 시 periodic/immediate JobScheduler 취소 + 실시간 감시 중지
- 일시정지 시 처리중 상태를 RETRY_WAIT로 복구
- 실행 중 작업은 1분 구간 경계에서 일시정지 확인
- Whisper CPU thread 최대 2개로 제한
- 실시간 감시 debounce 30초 + 5분 cooldown으로 반복 전체 스캔 방지
- 기존 16KiB/NDK28 설정 유지
