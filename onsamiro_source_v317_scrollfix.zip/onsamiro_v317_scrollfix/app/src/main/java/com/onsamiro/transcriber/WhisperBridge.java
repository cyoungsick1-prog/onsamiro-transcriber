package com.onsamiro.transcriber;

public final class WhisperBridge implements AutoCloseable {
    static { System.loadLibrary("onsamiro_whisper"); }
    private long handle;

    public WhisperBridge(String modelPath) {
        handle = nativeCreate(modelPath);
        if (handle == 0) throw new IllegalStateException("Whisper 모델을 열 수 없습니다");
    }

    public static boolean validateModel(String path) {
        try { return nativeValidate(path); }
        catch (Throwable t) { return false; }
    }

    public synchronized String transcribe(float[] pcm16k, String language) {
        return transcribe(pcm16k, language, 1);
    }

    public synchronized String transcribe(float[] pcm16k, String language, int requestedThreads) {
        if (handle == 0) throw new IllegalStateException("Whisper context closed");
        int threads = Math.max(1, Math.min(2, requestedThreads));
        String s = nativeTranscribe(handle, pcm16k, language == null ? "ko" : language, threads);
        if (s == null) throw new IllegalStateException("Whisper returned null");
        return s.trim();
    }

    @Override public synchronized void close() {
        if (handle != 0) {
            nativeFree(handle);
            handle = 0;
        }
    }

    private static native long nativeCreate(String modelPath);
    private static native boolean nativeValidate(String modelPath);
    private static native String nativeTranscribe(long handle, float[] pcm16k, String language, int threads);
    private static native void nativeFree(long handle);
}
