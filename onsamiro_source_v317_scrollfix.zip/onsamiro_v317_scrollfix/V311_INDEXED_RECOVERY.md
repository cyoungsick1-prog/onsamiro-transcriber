# v3.1.1 Indexed Recovery

## Why this exists
v3.1.0 correctly avoided reading audio bodies during recovery, but the SAF fallback still iterated up to 5,000 document metadata rows on a large recording folder. That can wake the provider/CPU unnecessarily and was visible in diagnostics as:

`메타데이터 5000개 ... 확인 한도 5000개 도달`

## v3.1.1 behavior
- Real-time content triggers still process the directly changed file when Android supplies its URI.
- Automatic recovery uses MediaStore's indexed `DATE_MODIFIED` + `RELATIVE_PATH` query for the selected primary-storage folder.
- Only rows changed since the saved checkpoint (with a 2-minute overlap) are returned.
- Automatic recovery never falls back to a 5,000-row SAF tree walk.
- If the one-time audio-read permission is missing, automatic bulk recovery is skipped instead of heating the phone.
- Explicit period transcription still supports historical SAF scanning when the indexed path is unavailable.
- No persistent notification and no foreground service are introduced.
