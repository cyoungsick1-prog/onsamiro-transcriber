# v3.1.13 realtime detection fix

- Fixes the observed state where MediaStore returned metadata 0 forever while the selected SAF recording folder actually contained new call recordings.
- Adds bounded metadata-only SAF fallback scanning when MediaStore is empty/unavailable.
- Foreground protection directly runs recovery about every 45 seconds instead of only re-arming a 120-minute JobScheduler fallback.
- Holds a bounded partial wake lock only while an actual recovery/transcription run is active.
- Serializes WorkCoordinator runs so foreground recovery and JobScheduler cannot transcribe the same job concurrently.
- Observes both the selected tree URI and its child-documents URI.
- Foreground-service initialization exceptions are contained so they cannot crash the app process.
- UI layout is unchanged.

- One-time migration rewinds the broken v3.1.12 recovery checkpoint back to the user's existing auto baseline, so recordings missed by v3.1.12 are eligible for recovery after updating.
