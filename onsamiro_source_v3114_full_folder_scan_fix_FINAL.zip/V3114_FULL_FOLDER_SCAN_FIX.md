# v3.1.14 full-folder-scan-fix

실기기 영상에서 자동전사 진단이 `메타데이터 1500개 · 새 후보 0개 · 확인 한도 1500개 도달`로 끝나는 문제를 수정했다.

- 자동 SAF 보완 확인의 1500개 하드 제한 제거
- 선택한 녹음 트리를 끝까지 메타데이터 확인
- 디렉터리 수정시각을 신뢰해 하위 폴더를 건너뛰던 자동 가지치기 제거
- 불완전/중단 스캔에서는 recovery checkpoint 전진 금지
- v3.1.13에서 놓친 파일을 위해 source-selection baseline으로 1회 rewind
- 기존 UI, foreground 보호, 45초 watchdog, 발열 자동중단 제거 상태 유지
