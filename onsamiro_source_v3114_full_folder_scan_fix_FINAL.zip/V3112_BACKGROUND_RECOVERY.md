# v3.1.12 Background Recovery

목표: 메인 UI와 기존 전사/기간전사 동작은 유지하고, 실시간 전사를 켜 둔 상태가 화면 OFF·최근 앱 제거·프로세스 재생성·재부팅 뒤에도 최대한 자동 복구되도록 백그라운드 실행 기반을 보강한다.

## 핵심 변경

- `TranscriptionKeepAliveService` 추가
  - `START_STICKY`
  - `android:stopWithTask="false"`
  - Android 14+ `specialUse` foreground-service type
  - 소리/진동 없는 LOW 중요도 상태 알림
- 실시간 전사 ON이면 앱 시작/재개 때 보호 서비스 확인
- 최근 앱에서 스와이프 제거해도 `onTaskRemoved()`에서 복구 작업과 JobScheduler 재확인
- `BOOT_COMPLETED`, `MY_PACKAGE_REPLACED` 뒤 기존 `auto_enabled`가 ON이면 보호 서비스 + 복구 자동 재개
- 선택 녹음 폴더에 `ContentObserver`를 추가하여 새 파일 변경 시 기존 JobScheduler 회복 경로를 즉시 자극
- 네트워크 재연결, 충전 연결, 배터리 정상 복귀, Doze 상태 변경 시 대기 작업 재시도 트리거
- 트리거 순간에만 최대 15초 `PARTIAL_WAKE_LOCK` 사용. 상시 WakeLock은 사용하지 않음
- 15분 watchdog은 실제 폴더 스캔을 반복하지 않고 사라진 JobScheduler 예약만 재등록
- 기존 Content URI Job + 주기 복구 + SQLite 작업원장을 그대로 유지하여 이중 안전망 구성
- `POST_NOTIFICATIONS` 런타임 권한은 추가하지 않음

## 의도적으로 유지한 것

- 메인 화면 레이아웃/버튼/문구 구조
- 기존 Whisper 처리 방식과 품질검사
- 기존 JobStore 재시도/부분복구
- Wi-Fi/충전/배터리 20% 조건
- 앱 자체 발열 자동중단 제거 상태
- 기존 applicationId (`com.onsamiro.transcriber.v3110`)로 업데이트 설치 가능

## 한계

Android 사용자가 설정에서 앱을 **강제 중지(Force stop)** 하면 시스템 정책상 앱이 스스로 다시 살아날 수 없다. 일반적인 프로세스 회수, 최근 앱 제거, 화면 OFF, Doze, 재부팅은 본 버전의 자동복구 대상이다.
