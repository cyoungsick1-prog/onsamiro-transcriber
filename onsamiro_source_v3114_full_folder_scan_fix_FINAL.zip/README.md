# 온새미로 자동전사 v3.1.12

Android 15+ 기준 로컬 Whisper 통화녹음 전사 앱 소스.

이번 버전은 **v3.1.11 화면/전사 기능을 유지하면서 백그라운드 자동복구 기반을 강화**한 버전이다.

- applicationId: `com.onsamiro.transcriber.v3110`
- versionCode: `311200`
- versionName: `3.1.12-background-recovery`
- compile/target SDK: 35
- NDK: 28.0.13004108
- CMake: 3.22.1
- ABI: arm64-v8a, x86_64
- 실시간 전사 ON 동안 저소음 Foreground Service + START_STICKY 보호
- JobScheduler Content URI trigger + periodic recovery 이중 안전망
- SQLite 파일/구간 작업원장
- 오늘/어제/최근 3일/최근 7일/직접 날짜 기간 전사
- **Android thermal status가 높아도 앱 자체에서 전사를 중단하지 않음**
- 사용자 즉시 중단, Wi-Fi/충전/배터리 조건, Android 시스템 자체 온도 보호는 유지

발열 중단 제거 상세는 `V3111_NO_THERMAL_STOP.md`, 백그라운드 복구 상세는 `V3112_BACKGROUND_RECOVERY.md` 참고.
