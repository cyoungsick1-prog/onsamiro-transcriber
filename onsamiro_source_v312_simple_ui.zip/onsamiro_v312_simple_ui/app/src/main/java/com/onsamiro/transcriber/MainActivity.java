package com.onsamiro.transcriber;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Daily-use home screen.
 *
 * The main screen intentionally exposes only four things:
 *  1) live transcription toggle
 *  2) period transcription
 *  3) current status
 *  4) immediate stop
 *
 * Technical diagnostics and setup are kept in Settings.
 */
public final class MainActivity extends Activity {
    private static final int MENU_SETTINGS = 1;
    private static final int MENU_HISTORY = 2;

    private AppConfig cfg;
    private TextView state;
    private TextView recent;
    private Button realtimeButton;
    private Button periodButton;
    private Button stopButton;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = new AppConfig(this);
        buildUi();

        // Re-arm lightweight jobs only. Opening the app must not scan the recording folder.
        Scheduler.reschedule(this);
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_HISTORY, 0, "기록");
        menu.add(0, MENU_SETTINGS, 1, "설정");
        return true;
    }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == MENU_SETTINGS) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        if (item.getItemId() == MENU_HISTORY) {
            startActivity(new Intent(this, HistoryActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(32));
        sv.addView(root);

        TextView title = text("온새미로 자동전사", 28, true);
        title.setPadding(0, 0, 0, dp(18));
        root.addView(title);

        // 1) Status display
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        statusCard.setBackground(roundRect("#F4F6F8", 18));

        state = text("", 23, true);
        recent = text("", 15, false);
        recent.setTextColor(Color.parseColor("#5B6168"));
        statusCard.addView(state);
        statusCard.addView(recent);
        root.addView(statusCard, matchWrap(dp(0), dp(18)));

        // 2) Live transcription button
        realtimeButton = bigButton("실시간 전사", v -> toggleRealtime());
        root.addView(realtimeButton, fullWidth(dp(70), dp(10)));

        // 3) Period transcription button
        periodButton = bigButton("기간별 전사", v -> showPeriodPicker());
        root.addView(periodButton, fullWidth(dp(70), dp(10)));

        // 4) Immediate stop button
        stopButton = bigButton("즉시 중단", v -> immediateStop());
        stopButton.setTextColor(Color.WHITE);
        stopButton.setBackground(roundRect("#C62828", 16));
        root.addView(stopButton, fullWidth(dp(70), dp(10)));

        setContentView(sv);
    }

    private void refresh() {
        if (state == null) return;

        boolean ready = cfg.basicReady(this);
        if (!ready) {
            state.setText("설정이 필요합니다");
            recent.setText("우측 상단 설정에서 폴더와 모델을 연결해주세요");
            realtimeButton.setText("설정하기");
            realtimeButton.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
            periodButton.setEnabled(false);
            stopButton.setEnabled(false);
            return;
        }

        realtimeButton.setOnClickListener(v -> toggleRealtime());
        periodButton.setEnabled(true);
        stopButton.setEnabled(true);

        JobStore.Stats stats;
        JobRecord last;
        try (JobStore s = new JobStore(this)) {
            stats = s.stats();
            last = s.lastCompleted();
        }

        int problems = stats.failed + stats.review + stats.partial;

        if (cfg.paused()) {
            state.setText("중단됨");
        } else if (!cfg.autoEnabled()) {
            state.setText("실시간 전사 꺼짐");
        } else if (RuntimeConstraints.thermalSevere(this)) {
            state.setText("발열 보호로 잠시 대기 중");
        } else if (stats.running > 0) {
            state.setText("전사 중 · " + stats.running + "건");
        } else if (problems > 0) {
            state.setText("확인 필요 · " + problems + "건");
        } else {
            state.setText("정상 작동 중");
        }

        if (last == null) {
            recent.setText("최근 전사: 없음");
        } else {
            recent.setText("최근 전사: " + fmtDateTime(last.updatedAt > 0 ? last.updatedAt : last.callTimeMs));
        }

        if (cfg.paused() || !cfg.autoEnabled()) {
            realtimeButton.setText("실시간 전사 시작");
        } else {
            realtimeButton.setText("실시간 전사 ON");
        }
    }

    private void toggleRealtime() {
        if (!cfg.basicReady(this)) {
            startActivity(new Intent(this, SettingsActivity.class));
            return;
        }

        if (cfg.paused() || !cfg.autoEnabled()) {
            cfg.setPaused(false);
            cfg.setAutoEnabled(true);
            Scheduler.reschedule(this);
            Scheduler.immediatePending(this, false);
            toast("실시간 전사를 시작했어요");
        } else {
            cfg.setAutoEnabled(false);
            Scheduler.cancelRealtime(this);
            toast("실시간 전사를 껐어요");
        }
        refresh();
    }

    private void immediateStop() {
        cfg.setPaused(true);
        Scheduler.cancelAll(this);
        try (JobStore s = new JobStore(this)) {
            s.recoverInterruptedRunning("사용자 즉시 중단 · 다시 시작하면 이어하기");
        }
        state.setText("중단됨");
        realtimeButton.setText("실시간 전사 시작");
        toast("모든 전사 작업을 중단했어요");
    }

    private void showPeriodPicker() {
        if (!cfg.basicReady(this)) {
            startActivity(new Intent(this, SettingsActivity.class));
            return;
        }

        String[] items = {"오늘", "어제", "최근 3일", "최근 7일", "날짜 직접 선택"};
        new AlertDialog.Builder(this)
                .setTitle("기간별 전사")
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0: startPreset(0); break;
                        case 1: startPreset(1); break;
                        case 2: startPreset(3); break;
                        case 3: startPreset(7); break;
                        default: pickCustomStart(); break;
                    }
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void startPreset(int days) {
        long[] r = rangeForPreset(days);
        Scheduler.historical(this, r[0], r[1]);
        state.setText("기간별 전사 시작됨");
        toast(labelForPreset(days) + " 전사를 시작했어요");
    }

    private void pickCustomStart() {
        Calendar now = Calendar.getInstance();
        new DatePickerDialog(this, (v, y, m, d) -> {
            Calendar start = Calendar.getInstance();
            start.set(y, m, d, 0, 0, 0);
            start.set(Calendar.MILLISECOND, 0);
            pickCustomEnd(start.getTimeInMillis());
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void pickCustomEnd(long startMs) {
        Calendar init = Calendar.getInstance();
        init.setTimeInMillis(Math.max(startMs, System.currentTimeMillis()));
        new DatePickerDialog(this, (v, y, m, day) -> {
            Calendar end = Calendar.getInstance();
            end.set(y, m, day, 23, 59, 59);
            end.set(Calendar.MILLISECOND, 999);
            long e = end.getTimeInMillis();
            if (e < startMs) {
                toast("종료일은 시작일보다 빠를 수 없어요");
                return;
            }
            Scheduler.historical(this, startMs, e);
            state.setText("기간별 전사 시작됨");
            toast(fmtDate(startMs) + " ~ " + fmtDate(e) + " 전사를 시작했어요");
        }, init.get(Calendar.YEAR), init.get(Calendar.MONTH), init.get(Calendar.DAY_OF_MONTH)).show();
    }

    private long[] rangeForPreset(int days) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long today = c.getTimeInMillis();
        if (days == 0) return new long[]{today, today + 86_400_000L - 1};
        if (days == 1) return new long[]{today - 86_400_000L, today - 1};
        return new long[]{today - (days - 1L) * 86_400_000L, System.currentTimeMillis()};
    }

    private String labelForPreset(int d) {
        return d == 0 ? "오늘" : d == 1 ? "어제" : "최근 " + d + "일";
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(Color.parseColor("#17191C"));
        v.setPadding(0, dp(5), 0, dp(5));
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    private Button bigButton(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams fullWidth(int height, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, height);
        p.setMargins(0, 0, 0, bottom);
        return p;
    }

    private LinearLayout.LayoutParams matchWrap(int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, top, 0, bottom);
        return p;
    }

    private GradientDrawable roundRect(String hex, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(hex));
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int dp(int x) {
        return (int)(x * getResources().getDisplayMetrics().density + .5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private String fmtDateTime(long ms) {
        return ms <= 0 ? "없음" : new SimpleDateFormat("MM-dd HH:mm", Locale.KOREA).format(new Date(ms));
    }

    private String fmtDate(long ms) {
        return new SimpleDateFormat("yyyy.MM.dd", Locale.KOREA).format(new Date(ms));
    }
}
