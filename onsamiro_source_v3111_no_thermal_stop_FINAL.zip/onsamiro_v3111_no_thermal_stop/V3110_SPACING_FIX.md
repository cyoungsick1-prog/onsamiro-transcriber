# v3.1.10 spacing fix

- Main screen top padding: 72dp -> 184dp. This is exactly two more 56dp downward moves, matching the user's request.
- Settings screen: added a 160dp bottom spacer so the final controls can scroll fully above the Android navigation area.
- Transcription, progress, duplicate-skip, low-heat recovery, and notification behavior are unchanged from v3.1.9.
