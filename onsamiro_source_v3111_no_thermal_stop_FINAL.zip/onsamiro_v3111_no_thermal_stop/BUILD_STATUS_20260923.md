# Build status — 2026-09-23

## 이번 수정 완료
- v3.1.10 소스를 기준으로 앱 자체 발열 자동중단 로직 제거
- RuntimeConstraints 발열 차단 제거
- WorkCoordinator 실행 전/작업 전/구간 전 발열 중단 제거
- 10분 thermal retry job 제거
- 메인 화면 `발열 보호 중` 상태 제거
- Settings에 `앱 발열 자동중단: 사용 안 함` 표시
- versionCode 311100 / versionName 3.1.11-no-thermal-stop
- applicationId `com.onsamiro.transcriber.v3110` 유지

## 이 환경에서 실행한 검증
- `scripts/static_audit.sh`: PASS
- no-thermal-stop regression test: PASS
- QualityGuard JVM self-test: PASS

## NOT_TESTED
이 실행 환경에는 Android SDK/Gradle/aapt2/d8/apksigner/zipalign이 없어 APK 재빌드는 실행하지 못했다.
따라서 실제 APK 설치, 기존 설치본 위 업데이트, 실제 통화 전사, 장시간 발열 상태 전사는 NOT_TESTED다.

동일 서명키로 빌드하면 기존 `com.onsamiro.transcriber.v3110` 설치본 위 업데이트가 가능하다. 서명키가 다르면 Android 정책상 기존 앱 삭제 후 설치가 필요할 수 있다.
