#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAN="$ROOT/app/src/main/AndroidManifest.xml"
CMAKE="$ROOT/app/src/main/cpp/CMakeLists.txt"
fail(){ echo "FAIL: $*"; exit 1; }
for bad in READ_CALL_LOG READ_SMS SEND_SMS SYSTEM_ALERT_WINDOW BIND_ACCESSIBILITY_SERVICE MANAGE_EXTERNAL_STORAGE RECORD_AUDIO QUERY_ALL_PACKAGES REQUEST_INSTALL_PACKAGES POST_NOTIFICATIONS FOREGROUND_SERVICE; do
  if grep -q "$bad" "$MAN"; then fail "unexpected sensitive permission/API marker $bad"; fi
done
grep -q 'usesCleartextTraffic="false"' "$MAN" || fail "cleartext not disabled"
grep -q 'max-page-size=16384' "$CMAKE" || fail "16 KiB linker flag missing"
grep -q 'common-page-size=16384' "$CMAKE" || fail "16 KiB common page flag missing"
if grep -R -q 'RealtimeMonitorService' "$ROOT/app/src/main"; then fail "foreground realtime service reference remains"; fi
if find "$ROOT" -type f \( -name '*.p12' -o -name '*.jks' -o -name '*.keystore' -o -name '*.key' \) | grep -q .; then fail "signing/private key found in source tree"; fi
if find "$ROOT" -type f -name '*.so' | grep -q .; then fail "prebuilt native .so found; clean source must rebuild native code"; fi
python3 "$ROOT/tools/ThermalRecoverySelfTest.py"
echo "STATIC_AUDIT PASS"
