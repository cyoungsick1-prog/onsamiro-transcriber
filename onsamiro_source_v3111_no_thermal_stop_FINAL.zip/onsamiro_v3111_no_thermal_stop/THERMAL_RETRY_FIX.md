# v3.1.10 thermal retry fix

Changes in this source copy:

- Check Android thermal status before any native Whisper model validation.
- Background model checks now verify only that the selected file exists, is readable, and has a plausible size. Download and explicit model selection still parse the model; actual transcription opens it when needed.
- Empty recovery scans no longer open the Whisper model.
- If thermal protection pauses automatic work, schedule a guarded retry after 10 minutes. The retry still checks thermal, pause, Wi-Fi, and battery conditions; it does not bypass them.
- Add a static regression check for the ordering and retry wiring.

Validation completed here: static security audit, thermal-retry static regression, Python syntax checks, and shell syntax checks PASS.

Not tested here: Java compilation, Gradle/Android build, APK signature, 16 KiB native alignment, emulator install/run, and device thermal behavior. This workspace has no Gradle, Android SDK, or Java compiler. Run the supplied GitHub Actions workflow to perform build-time checks.
