# v3.1.11 — 앱 발열 자동중단 제거

기준: 2026-09-23

## 변경
- 앱이 Android thermal status가 SEVERE 이상이라는 이유만으로 전사를 중단하지 않도록 변경했다.
- RuntimeConstraints의 발열 차단 조건을 제거했다.
- WorkCoordinator의 실행 전/파일 전/구간 전 발열 중단 및 10분 재시도 로직을 제거했다.
- Scheduler의 전용 thermal retry 작업을 제거했다.
- 메인 화면의 `발열 보호 중 / 휴대폰이 식으면 자동으로 다시 이어갑니다` 상태를 제거했다.
- 설정 진단에는 `앱 발열 자동중단: 사용 안 함`으로 표시한다.
- Wi-Fi 전용, 충전 중만, 배터리 부족 보호, 사용자 즉시 중단, Android 자체 과열/스로틀링 동작은 변경하지 않았다.

## 버전
- applicationId: `com.onsamiro.transcriber.v3110` 유지
- versionCode: 311100
- versionName: `3.1.11-no-thermal-stop`

## 주의
앱 자체 발열 차단만 제거한 것이다. Android/삼성의 시스템 수준 온도 보호는 앱에서 제거하지 않으며, 기기 온도가 높으면 운영체제가 성능을 낮추거나 프로세스를 제한할 수 있다.
