# v3.1.9 top offset fix

- Main screen content is moved down by an additional 56dp.
- Effective top padding is 72dp (56dp action-bar clearance + 16dp visual spacing).
- No transcription, recovery, progress, duplicate-skip, or low-heat logic changed.
