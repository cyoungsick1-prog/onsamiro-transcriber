# 온새미로 자동전사 v3.1.11

Android 15+ 기준 로컬 Whisper 통화녹음 전사 앱 소스.

이번 버전은 **v3.1.10 화면/전사 기능을 유지하면서 앱 자체 발열 자동중단만 제거**한 버전이다.

- applicationId: `com.onsamiro.transcriber.v3110`
- versionCode: `311100`
- versionName: `3.1.11-no-thermal-stop`
- compile/target SDK: 35
- NDK: 28.0.13004108
- CMake: 3.22.1
- ABI: arm64-v8a, x86_64
- 지속 알림/Foreground Service 없음
- JobScheduler Content URI trigger + periodic recovery
- SQLite 파일/구간 작업원장
- 오늘/어제/최근 3일/최근 7일/직접 날짜 기간 전사
- **Android thermal status가 높아도 앱 자체에서 전사를 중단하지 않음**
- 사용자 즉시 중단, Wi-Fi/충전/배터리 조건, Android 시스템 자체 온도 보호는 유지

변경 상세는 `V3111_NO_THERMAL_STOP.md` 참고.
