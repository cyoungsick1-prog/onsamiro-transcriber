#include <jni.h>
#include <android/log.h>
#include <string>
#include <algorithm>
#include "whisper.h"

#define TAG "OnsamiroWhisper"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG,__VA_ARGS__)

static std::string jstr(JNIEnv *env,jstring s){if(!s)return {};const char *p=env->GetStringUTFChars(s,nullptr);std::string out=p?p:"";if(p)env->ReleaseStringUTFChars(s,p);return out;}

extern "C" JNIEXPORT jlong JNICALL Java_com_onsamiro_transcriber_WhisperBridge_nativeCreate(JNIEnv *env,jclass,jstring path){
    std::string p=jstr(env,path); whisper_context_params cp=whisper_context_default_params();
    whisper_context *ctx=whisper_init_from_file_with_params(p.c_str(),cp); return reinterpret_cast<jlong>(ctx);
}
extern "C" JNIEXPORT jboolean JNICALL Java_com_onsamiro_transcriber_WhisperBridge_nativeValidate(JNIEnv *env,jclass,jstring path){
    std::string p=jstr(env,path); whisper_context_params cp=whisper_context_default_params(); whisper_context *ctx=whisper_init_from_file_with_params(p.c_str(),cp); if(!ctx)return JNI_FALSE; whisper_free(ctx);return JNI_TRUE;
}
extern "C" JNIEXPORT jstring JNICALL Java_com_onsamiro_transcriber_WhisperBridge_nativeTranscribe(JNIEnv *env,jclass,jlong ptr,jfloatArray audio,jstring language,jint threads){
    auto *ctx=reinterpret_cast<whisper_context*>(ptr); if(!ctx||!audio)return env->NewStringUTF("");
    const jsize n=env->GetArrayLength(audio); jfloat *pcm=env->GetFloatArrayElements(audio,nullptr); if(!pcm)return env->NewStringUTF("");
    std::string lang=jstr(env,language); whisper_full_params p=whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.print_realtime=false;p.print_progress=false;p.print_timestamps=false;p.print_special=false;p.translate=false;p.no_context=true;p.single_segment=false;p.language=lang.empty()?"ko":lang.c_str();p.n_threads=std::max(1,(int)threads);
    int rc=whisper_full(ctx,p,pcm,n); env->ReleaseFloatArrayElements(audio,pcm,JNI_ABORT); if(rc!=0){LOGE("whisper_full failed: %d",rc);return nullptr;}
    std::string out;int segs=whisper_full_n_segments(ctx);for(int i=0;i<segs;i++){const char *t=whisper_full_get_segment_text(ctx,i);if(t){if(!out.empty())out.push_back(' ');out+=t;}}
    return env->NewStringUTF(out.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_com_onsamiro_transcriber_WhisperBridge_nativeFree(JNIEnv*,jclass,jlong ptr){auto *ctx=reinterpret_cast<whisper_context*>(ptr);if(ctx)whisper_free(ctx);}
