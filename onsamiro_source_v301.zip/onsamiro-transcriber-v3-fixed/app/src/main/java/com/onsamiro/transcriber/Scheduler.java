package com.onsamiro.transcriber;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.net.NetworkCapabilities;

public final class Scheduler {
    private static final int PERIODIC_ID=7310, IMMEDIATE_ID=7311;
    private Scheduler() {}

    public static void reschedule(Context c) {
        AppConfig cfg=new AppConfig(c); JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        js.cancel(PERIODIC_ID);
        if (!cfg.autoEnabled()) { cfg.setNextExpectedMs(0); return; }
        long period=Math.max(30,cfg.intervalMinutes())*60_000L;
        JobInfo.Builder b=new JobInfo.Builder(PERIODIC_ID,new ComponentName(c,ScanJobService.class))
                .setPersisted(true).setPeriodic(period).setBackoffCriteria(15*60_000L,JobInfo.BACKOFF_POLICY_EXPONENTIAL);
        if (cfg.wifiOnly()) b.setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED);
        if (cfg.chargingOnly()) b.setRequiresCharging(true);
        if (cfg.batteryNotLow()) b.setRequiresBatteryNotLow(true);
        js.schedule(b.build());
        cfg.setNextExpectedMs(System.currentTimeMillis()+period);
    }

    public static void immediate(Context c, boolean force) {
        JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        android.os.PersistableBundle x=new android.os.PersistableBundle();x.putBoolean("force",force);
        JobInfo.Builder b=new JobInfo.Builder(IMMEDIATE_ID,new ComponentName(c,ScanJobService.class)).setExtras(x).setMinimumLatency(0).setOverrideDeadline(15_000L);
        js.schedule(b.build());
    }
}
