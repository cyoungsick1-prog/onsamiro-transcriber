package com.onsamiro.transcriber;

import android.app.job.JobParameters;
import android.app.job.JobService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ScanJobService extends JobService {
    private final ExecutorService one=Executors.newSingleThreadExecutor();
    private volatile WorkCoordinator coordinator;

    @Override public boolean onStartJob(JobParameters params) {
        final boolean force=params.getExtras()!=null && params.getExtras().getBoolean("force",false);
        coordinator=new WorkCoordinator(getApplicationContext());
        one.execute(() -> {
            try { coordinator.run(force); }
            finally { jobFinished(params,false); }
        });
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) {
        if(coordinator!=null) coordinator.requestStop("운영체제가 작업을 중단함");
        return true;
    }
    @Override public void onDestroy(){one.shutdownNow();super.onDestroy();}
}
