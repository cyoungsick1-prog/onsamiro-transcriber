package com.onsamiro.transcriber;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_SOURCE=100,PICK_OUTPUT=101,PICK_MODEL=102;
    private final ExecutorService bg=Executors.newSingleThreadExecutor();
    private AppConfig cfg; private TextView readiness,runtime,stats,current; private ProgressBar progress; private ListView list; private List<JobRecord> rows=new ArrayList<>(); private Spinner interval;

    @Override protected void onCreate(Bundle b){super.onCreate(b);cfg=new AppConfig(this);requestNotif();buildUi();Scheduler.reschedule(this);RealtimeMonitorService.sync(this);refresh();}
    @Override protected void onResume(){super.onResume();refresh();}
    @Override protected void onDestroy(){bg.shutdownNow();super.onDestroy();}

    private void buildUi(){ScrollView sv=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(12),dp(16),dp(24));sv.addView(root);TextView title=t("온새미로 익시오 자동전사",28,true);root.addView(title);root.addView(t("로컬 Whisper 전사 · 검증 통과 결과만 최종 TXT 저장",15,false));readiness=t("",18,true);root.addView(readiness);root.addView(button("1. 익시오 녹음폴더 선택",v->pickTree(PICK_SOURCE)));root.addView(button("2. TXT 저장폴더 선택",v->pickTree(PICK_OUTPUT)));root.addView(button("3. 추천 한국어용 다국어 모델 다운로드",v->downloadModel()));root.addView(button("모델 파일 직접 선택",v->pickModel()));
        root.addView(t("실행 방식",22,true));interval=new Spinner(this);String[] opts={"30분","1시간","2시간 (기본)","4시간"};interval.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opts));interval.setSelection(indexFor(cfg.intervalMinutes()));root.addView(interval);root.addView(button("선택한 주기 적용",v->{int[] m={30,60,120,240};cfg.setIntervalMinutes(m[interval.getSelectedItemPosition()]);Scheduler.reschedule(this);refresh();}));
        CheckBox auto=check("주기 자동실행",cfg.autoEnabled(),v->{cfg.setAutoEnabled(((CheckBox)v).isChecked());Scheduler.reschedule(this);});root.addView(auto);CheckBox realtime=check("실시간 감시 (폴더 변경 이벤트가 오는 기기에서만 즉시 반응)",cfg.realtimeEnabled(),v->{cfg.setRealtimeEnabled(((CheckBox)v).isChecked());RealtimeMonitorService.sync(this);});root.addView(realtime);CheckBox wifi=check("Wi-Fi에서만 자동 실행",cfg.wifiOnly(),v->{cfg.setWifiOnly(((CheckBox)v).isChecked());Scheduler.reschedule(this);});root.addView(wifi);CheckBox charging=check("충전 중에만 자동 실행",cfg.chargingOnly(),v->{cfg.setChargingOnly(((CheckBox)v).isChecked());Scheduler.reschedule(this);});root.addView(charging);CheckBox batt=check("배터리 20% 미만이면 자동 실행 대기",cfg.batteryNotLow(),v->{cfg.setBatteryNotLow(((CheckBox)v).isChecked());Scheduler.reschedule(this);});root.addView(batt);
        runtime=t("",15,false);root.addView(runtime);root.addView(t("날짜 범위",22,true));LinearLayout quick=new LinearLayout(this);quick.setOrientation(LinearLayout.HORIZONTAL);quick.addView(small("오늘",v->setRange(0)));quick.addView(small("어제",v->setRange(1)));quick.addView(small("최근 3일",v->setRange(3)));quick.addView(small("최근 7일",v->setRange(7)));root.addView(quick);root.addView(button("지금 목록 확인",v->runScan(true)));root.addView(button("전사 시작 / 이어하기 (수동은 제약 무시)",v->{Scheduler.immediate(this,true);toast("작업 요청됨");}));root.addView(button("일시정지 / 다시 시작",v->{cfg.setPaused(!cfg.paused());refresh();}));root.addView(button("실패·확인필요 다시하기",v->{try(JobStore s=new JobStore(this)){s.retryFailuresAndReviews();}Scheduler.immediate(this,true);refresh();}));root.addView(button("기존 TXT 의심결과 빠른 검사",v->auditLegacy()));
        stats=t("",20,true);root.addView(stats);progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);root.addView(progress,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(12)));current=t("",15,false);root.addView(current);list=new ListView(this);root.addView(list,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(420)));list.setOnItemClickListener((p,v,pos,id)->showJob(rows.get(pos)));setContentView(sv);}

    private void refresh(){if(readiness==null)return;boolean ready=cfg.basicReady(this);StringBuilder r=new StringBuilder(ready?"설정 완료":"설정이 필요합니다");if(cfg.sourceTree().isEmpty())r.append("\n· 녹음폴더 미선택");if(cfg.outputTree().isEmpty())r.append("\n· 저장폴더 미선택");if(cfg.modelPath().isEmpty())r.append("\n· 모델 미선택");readiness.setText(r.toString());RuntimeConstraints.Check ck=RuntimeConstraints.check(this,cfg);runtime.setText("모드: "+(cfg.paused()?"일시정지":cfg.realtimeEnabled()?"실시간+주기":"주기")+" · 자동주기 "+cfg.intervalMinutes()+"분\n최근 실제 실행: "+fmt(cfg.lastRunMs())+" · 다음 예상: "+fmt(cfg.nextExpectedMs())+"\n현재 제약: "+(ck.ok?"실행 가능":ck.reason)+"\n최근 상태: "+cfg.lastRunNote());try(JobStore s=new JobStore(this)){JobStore.Stats x=s.stats();stats.setText("전체 "+x.total+" · 완료 "+x.done+" · 처리중 "+x.running+" · 대기 "+x.waiting+" · 일부완료 "+x.partial+" · 실패 "+x.failed+" · 확인필요 "+x.review);progress.setProgress(x.percent());rows=s.recent(80);}List<String> labels=new ArrayList<>();for(JobRecord j:rows)labels.add(j.summary());list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,labels));current.setText(rows.isEmpty()?"통화별 작업이 없습니다":"항목을 누르면 상세 상태·결과·재시도를 볼 수 있습니다");}
    private void showJob(JobRecord j){String msg="날짜: "+new Date(j.callTimeMs)+"\n상대/파일: "+j.contactHint+"\n길이: "+j.durationMs/1000+"초\n상태: "+j.status+"\n단계: "+j.stage+"\n경과: "+elapsed(j.startedAt)+"\n마지막 변화: "+fmt(j.updatedAt)+"\n구간: "+j.doneSegments+"/"+j.totalSegments+" · 실패 "+j.failedSegments+"\n재시도: "+j.retryCount+"\n대기이유: "+j.waitReason+"\n실패이유: "+j.failReason+"\n저장: "+(j.finalUri.isEmpty()?"최종 TXT 없음":j.finalUri)+"\n미리보기: "+j.resultPreview;new AlertDialog.Builder(this).setTitle(j.displayName).setMessage(msg).setPositiveButton("이 통화 재시도",(d,w)->{try(JobStore s=new JobStore(this)){s.retry(j.id);}Scheduler.immediate(this,true);refresh();}).setNeutralButton("사용자 제외",(d,w)->{try(JobStore s=new JobStore(this)){s.exclude(j.id);}refresh();}).setNegativeButton("닫기",null).show();}

    private void runScan(boolean hist){bg.execute(()->{new WorkCoordinator(getApplicationContext()).scanOnly(hist);runOnUiThread(this::refresh);});}
    private void auditLegacy(){bg.execute(()->{List<LegacyResultAuditor.Finding> f=LegacyResultAuditor.audit(this,200);runOnUiThread(()->new AlertDialog.Builder(this).setTitle("기존 TXT 검사").setMessage(f.isEmpty()?"간단 검사에서 의심 TXT를 찾지 못했습니다. 이 검사는 원본 음성과 대조하는 전체 품질검사가 아닙니다.":formatFindings(f)).setPositiveButton("확인",null).show());});}
    private String formatFindings(List<LegacyResultAuditor.Finding> f){StringBuilder s=new StringBuilder();for(int i=0;i<Math.min(30,f.size());i++)s.append("• ").append(f.get(i).name).append(" : ").append(f.get(i).reason).append('\n');if(f.size()>30)s.append("외 ").append(f.size()-30).append("건");return s.toString();}
    private void downloadModel(){bg.execute(()->{try{File f=ModelManager.downloadRecommended(this,(d,t,stage)->runOnUiThread(()->{readiness.setText(stage+(t>0?" "+(d*100/Math.max(1,t))+"%":""));}));cfg.setModelPath(f.getAbsolutePath());runOnUiThread(()->{toast("모델 준비 완료");refresh();});}catch(Throwable t){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("모델 준비 실패").setMessage(t.getClass().getSimpleName()+"\n"+(t.getMessage()==null?"":t.getMessage())).setPositiveButton("확인",null).show());}});}
    private void pickTree(int req){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,req);}private void pickModel(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,PICK_MODEL);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri u=data.getData();try{if(req==PICK_SOURCE||req==PICK_OUTPUT){getContentResolver().takePersistableUriPermission(u,data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));if(req==PICK_SOURCE)cfg.setSourceTree(u.toString());else cfg.setOutputTree(u.toString());Scheduler.reschedule(this);RealtimeMonitorService.sync(this);}else if(req==PICK_MODEL){
                    final Uri modelUri=u;
                    bg.execute(()->{
                        try{File d=new File(getFilesDir(),"models");d.mkdirs();File f=new File(d,"selected-model.bin");File part=new File(d,"selected-model.bin.part");try(java.io.InputStream in=getContentResolver().openInputStream(modelUri);java.io.FileOutputStream o=new java.io.FileOutputStream(part,false)){if(in==null)throw new IllegalStateException("모델 파일 열기 실패");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)o.write(b,0,n);o.getFD().sync();}if(!WhisperBridge.validateModel(part.getAbsolutePath())){part.delete();throw new IllegalStateException("Whisper가 이 모델을 열지 못했습니다");}if(f.exists())f.delete();if(!part.renameTo(f))throw new IllegalStateException("모델 저장 완료 처리 실패");cfg.setModelPath(f.getAbsolutePath());runOnUiThread(()->{toast("모델 선택 완료");refresh();});}catch(Throwable t){runOnUiThread(()->toast("모델 설정 실패: "+t.getMessage()));}
                    });
                    return;
                }}catch(Throwable t){toast("설정 실패: "+t.getMessage());}refresh();}
    private void setRange(int days){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);long today=c.getTimeInMillis(),s,e;if(days==0){s=today;e=today+86_400_000L-1;}else if(days==1){s=today-86_400_000L;e=today-1;}else{s=today-(days-1L)*86_400_000L;e=System.currentTimeMillis();}cfg.setRange(s,e);toast("범위: "+fmt(s)+" ~ "+fmt(e));}
    private void requestNotif(){if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},55);}
    private Button button(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setOnClickListener(l);b.setAllCaps(false);return b;}private Button small(String s,View.OnClickListener l){Button b=button(s,l);b.setTextSize(12);b.setLayoutParams(new LinearLayout.LayoutParams(0,dp(52),1));return b;}private CheckBox check(String s,boolean v,View.OnClickListener l){CheckBox c=new CheckBox(this);c.setText(s);c.setChecked(v);c.setOnClickListener(l);return c;}private TextView t(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setPadding(0,dp(8),0,dp(8));if(bold)v.setTypeface(null,Typeface.BOLD);return v;}private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}private int indexFor(int m){return m==30?0:m==60?1:m==240?3:2;}private String fmt(long ms){return ms<=0?"없음":new SimpleDateFormat("MM-dd HH:mm:ss",Locale.KOREA).format(new Date(ms));}private String elapsed(long start){if(start<=0)return "-";long s=Math.max(0,(System.currentTimeMillis()-start)/1000);return s+"초";}
}
