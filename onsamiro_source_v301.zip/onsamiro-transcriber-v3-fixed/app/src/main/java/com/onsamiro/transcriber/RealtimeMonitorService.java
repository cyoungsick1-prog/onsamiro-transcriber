package com.onsamiro.transcriber;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public final class RealtimeMonitorService extends Service {
    private static final String CH="onsamiro_realtime";
    private final Handler h=new Handler(Looper.getMainLooper());
    private ContentObserver observer; private final Runnable fire=()->Scheduler.immediate(this,false);

    @Override public void onCreate(){super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(android.os.Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CH,"온새미로 자동전사 감시",NotificationManager.IMPORTANCE_LOW));Notification n=new Notification.Builder(this,CH).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("온새미로 자동전사").setContentText("선택한 녹음폴더의 변경을 기다리는 중").setOngoing(true).build();startForeground(7312,n);registerObserver();}
    private void registerObserver(){AppConfig cfg=new AppConfig(this);if(!cfg.realtimeEnabled()||cfg.sourceTree().isEmpty()){stopSelf();return;}Uri u=Uri.parse(cfg.sourceTree());observer=new ContentObserver(h){@Override public void onChange(boolean selfChange,Uri uri){h.removeCallbacks(fire);h.postDelayed(fire,5000);}};getContentResolver().registerContentObserver(u,true,observer);}
    @Override public int onStartCommand(Intent i,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){h.removeCallbacks(fire);if(observer!=null)try{getContentResolver().unregisterContentObserver(observer);}catch(Throwable ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    public static void sync(Context c){AppConfig cfg=new AppConfig(c);Intent i=new Intent(c,RealtimeMonitorService.class);if(cfg.realtimeEnabled()&&!cfg.sourceTree().isEmpty())androidxFreeStartForeground(c,i);else c.stopService(i);}
    private static void androidxFreeStartForeground(Context c,Intent i){if(android.os.Build.VERSION.SDK_INT>=26)c.startForegroundService(i);else c.startService(i);}
}
