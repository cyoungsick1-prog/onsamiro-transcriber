package com.onsamiro.transcriber;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        Context app = context.getApplicationContext();
        Scheduler.reschedule(app);
        try {
            RealtimeMonitorService.sync(app);
        } catch (Throwable t) {
            new AppConfig(app).setLastRunNote("재부팅 후 실시간 감시 재시작 대기: " + t.getClass().getSimpleName());
        }
    }
}
