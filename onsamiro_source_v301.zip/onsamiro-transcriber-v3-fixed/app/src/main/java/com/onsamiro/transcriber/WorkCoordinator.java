package com.onsamiro.transcriber;

import android.content.Context;
import android.net.Uri;

import java.util.List;

public final class WorkCoordinator {
    private static final long SEGMENT_MS=180_000L;
    private final Context c;private final AppConfig cfg;private final JobStore store;private volatile boolean stop;private volatile String stopReason="";
    public WorkCoordinator(Context c){this.c=c;cfg=new AppConfig(c);store=new JobStore(c);}
    public void requestStop(String reason){stop=true;stopReason=reason;}

    public void run(boolean force){
        long now=System.currentTimeMillis();
        try {
            if(!cfg.basicReady(c)){cfg.setLastRunNote("설정 필요: 녹음폴더·저장폴더·모델 확인");return;}
            if(!ModelManager.validateExisting(new java.io.File(cfg.modelPath()))){cfg.setLastRunNote("모델 확인 실패: 다시 선택하거나 다운로드 필요");return;}
            RuntimeConstraints.Check ck=RuntimeConstraints.check(c,cfg);if(!force&&!ck.ok){cfg.setLastRunNote(ck.reason);return;}
            DocumentScanner.Result scan=new DocumentScanner(c,store).scan(false);cfg.setLastRunNote("목록 "+scan.visited+"개 확인 · 신규/변경 "+scan.discovered+"개"+(scan.note.isEmpty()?"":" · "+scan.note));
            try(WhisperBridge whisper=new WhisperBridge(cfg.modelPath())){
                for(JobRecord j:store.actionable(System.currentTimeMillis(),30)){if(stop){store.updateJob(j.id,Status.RETRY_WAIT,"중단됨","",stopReason);break;}processOne(j,whisper);}
            }
        } catch(Throwable t){cfg.setLastRunNote("실행 오류: "+t.getClass().getSimpleName()+" · "+safe(t.getMessage()));}
        finally{cfg.setLastRunMs(System.currentTimeMillis());if(cfg.autoEnabled())cfg.setNextExpectedMs(System.currentTimeMillis()+cfg.intervalMinutes()*60_000L);store.close();}
    }

    public void scanOnly(boolean historical){try{DocumentScanner.Result r=new DocumentScanner(c,store).scan(historical);cfg.setLastRunNote("목록 확인: "+r.visited+"개 · 대상 "+r.discovered+"개"+(r.note.isEmpty()?"":" · "+r.note));cfg.setLastRunMs(System.currentTimeMillis());}finally{store.close();}}

    private void processOne(JobRecord j,WhisperBridge whisper){
        try {
            store.updateJob(j.id,Status.FETCHING,"원본 정보 확인","","");Uri uri=Uri.parse(j.sourceUri);long dur=AudioChunkDecoder.durationMs(c,uri);if(dur<=0){store.scheduleRetry(j.id,"통화 길이를 읽지 못함");return;}int total=Math.max(1,(int)Math.ceil(dur/(double)SEGMENT_MS));store.setMetadata(j.id,dur,total);store.ensureSegments(j.id,dur,SEGMENT_MS);
            List<SegmentRecord> segs=store.pendingSegments(j.id);for(SegmentRecord s:segs){if(stop)return;try{store.updateJob(j.id,Status.TRANSCRIBING,"구간 "+(s.index+1)+"/"+total+" 디코딩·전사","","");AudioChunkDecoder.Decoded d=AudioChunkDecoder.decodeRange(c,uri,s.startMs,s.endMs);String text=whisper.transcribe(d.pcm16k,"ko");s.decodedMs=d.decodedMs;s.speechMs=d.speechMs;s.text=text;s.status=Status.DONE;s.error="";store.saveSegment(s);}catch(Throwable x){s.retryCount++;s.error=safe(x.getMessage());s.status=s.retryCount<3?Status.RETRY_WAIT:Status.FAILED;store.saveSegment(s);}}
            store.refreshAggregates(j.id);j=store.get(j.id);StringBuilder all=new StringBuilder();for(SegmentRecord s:store.allSegments(j.id)){if(s.text!=null&&!s.text.trim().isEmpty()){if(all.length()>0)all.append('\n');all.append(s.text.trim());}}
            QualityGuard.Input qi=new QualityGuard.Input();qi.durationMs=j.durationMs;qi.decodedMs=j.decodedDurationMs;qi.speechMs=j.speechMs;qi.processedUntilMs=j.processedUntilMs;qi.totalSegments=j.totalSegments;qi.doneSegments=j.doneSegments;qi.failedSegments=j.failedSegments;qi.text=all.toString();store.updateJob(j.id,Status.QUALITY_CHECK,"내용 검사","","");QualityGuard.Result qr=QualityGuard.evaluate(qi);OutputStore os=new OutputStore(c);String draft=os.writeDraft(j,all.toString(),qr);
            if(qr.verdict==QualityGuard.Verdict.PASS){store.updateJob(j.id,Status.SAVING,"최종 TXT 저장","","");String finalUri=os.writeFinalNoOverwrite(j,all.toString(),qr);store.setResult(j.id,Status.DONE,"완료",preview(all.toString()),draft,finalUri,qr.reasonText());}
            else if(qr.verdict==QualityGuard.Verdict.NO_AUDIO){store.setResult(j.id,Status.NO_AUDIO,"음성 없음",preview(all.toString()),draft,"",qr.reasonText());}
            else if(qr.verdict==QualityGuard.Verdict.PARTIAL){
                if(store.countSegments(j.id,Status.RETRY_WAIT)>0){store.setResult(j.id,Status.PARTIAL,"일부 완료",preview(all.toString()),draft,"",qr.reasonText());store.schedulePartialRetry(j.id,qr.reasonText());}
                else store.setResult(j.id,Status.PARTIAL,"일부 완료 · 수동 확인 필요",preview(all.toString()),draft,"",qr.reasonText());
            }
            else {store.setResult(j.id,Status.REVIEW_REQUIRED,"확인 필요",preview(all.toString()),draft,"",qr.reasonText());}
        } catch(SecurityException se){store.updateJob(j.id,Status.REVIEW_REQUIRED,"원본 접근 권한 확인","권한 필요",safe(se.getMessage()));}
        catch(Throwable t){store.scheduleRetry(j.id,t.getClass().getSimpleName()+" · "+safe(t.getMessage()));}
    }
    private static String preview(String s){String x=s==null?"":s.replaceAll("\\s+"," ").trim();return x.length()>160?x.substring(0,160)+"…":x;}private static String safe(String s){return s==null?"":s;}
}
