package com.onsamiro.transcriber;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import java.io.File;

public final class AppConfig {
    private static final String PREF = "onsamiro_cfg_v3";
    private final SharedPreferences p;
    public AppConfig(Context c) { p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public String sourceTree() { return p.getString("source_tree", ""); }
    public String outputTree() { return p.getString("output_tree", ""); }
    public String modelPath() { return p.getString("model_path", ""); }
    public void setSourceTree(String v) { p.edit().putString("source_tree", v).apply(); }
    public void setOutputTree(String v) { p.edit().putString("output_tree", v).apply(); }
    public void setModelPath(String v) { p.edit().putString("model_path", v).apply(); }

    public int intervalMinutes() { return p.getInt("interval_min", 120); }
    public void setIntervalMinutes(int v) { p.edit().putInt("interval_min", v).apply(); }
    public boolean autoEnabled() { return p.getBoolean("auto_enabled", true); }
    public void setAutoEnabled(boolean v) { p.edit().putBoolean("auto_enabled", v).apply(); }
    public boolean paused() { return p.getBoolean("paused", false); }
    public void setPaused(boolean v) { p.edit().putBoolean("paused", v).apply(); }
    public boolean realtimeEnabled() { return p.getBoolean("realtime_enabled", false); }
    public void setRealtimeEnabled(boolean v) { p.edit().putBoolean("realtime_enabled", v).apply(); }
    public boolean wifiOnly() { return p.getBoolean("wifi_only", false); }
    public void setWifiOnly(boolean v) { p.edit().putBoolean("wifi_only", v).apply(); }
    public boolean chargingOnly() { return p.getBoolean("charging_only", false); }
    public void setChargingOnly(boolean v) { p.edit().putBoolean("charging_only", v).apply(); }
    public boolean batteryNotLow() { return p.getBoolean("battery_not_low", true); }
    public void setBatteryNotLow(boolean v) { p.edit().putBoolean("battery_not_low", v).apply(); }

    public long lastRunMs() { return p.getLong("last_run_ms", 0); }
    public void setLastRunMs(long v) { p.edit().putLong("last_run_ms", v).apply(); }
    public long nextExpectedMs() { return p.getLong("next_expected_ms", 0); }
    public void setNextExpectedMs(long v) { p.edit().putLong("next_expected_ms", v).apply(); }
    public long lastScanMs() { return p.getLong("last_scan_ms", 0); }
    public void setLastScanMs(long v) { p.edit().putLong("last_scan_ms", v).apply(); }
    public String lastRunNote() { return p.getString("last_run_note", "아직 실행 안 됨"); }
    public void setLastRunNote(String v) { p.edit().putString("last_run_note", v).apply(); }

    public long rangeStartMs() { return p.getLong("range_start", 0); }
    public long rangeEndMs() { return p.getLong("range_end", Long.MAX_VALUE); }
    public void setRange(long s, long e) { p.edit().putLong("range_start", s).putLong("range_end", e).apply(); }

    public boolean basicReady(Context c) {
        if (sourceTree().isEmpty() || outputTree().isEmpty() || modelPath().isEmpty()) return false;
        File m = new File(modelPath());
        if (!m.isFile() || m.length() < 1024 * 1024) return false;
        return hasPersistedPermission(c, sourceTree(), true, false)
                && hasPersistedPermission(c, outputTree(), true, true);
    }

    private boolean hasPersistedPermission(Context c, String uri, boolean needRead, boolean needWrite) {
        try {
            Uri u = Uri.parse(uri);
            for (android.content.UriPermission up : c.getContentResolver().getPersistedUriPermissions()) {
                if (!up.getUri().equals(u)) continue;
                boolean readOk = !needRead || up.isReadPermission();
                boolean writeOk = !needWrite || up.isWritePermission();
                if (readOk && writeOk) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }
}
