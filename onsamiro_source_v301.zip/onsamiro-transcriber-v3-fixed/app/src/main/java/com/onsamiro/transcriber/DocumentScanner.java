package com.onsamiro.transcriber;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import java.util.ArrayDeque;
import java.util.Locale;

public final class DocumentScanner {
    public static final class Result { public int visited, discovered; public boolean truncated; public String note=""; }
    private static final int MAX_DOCS=1200, MAX_DEPTH=6;
    private static final long LOOKBACK=24L*60*60*1000;
    private final Context c; private final JobStore store; private final AppConfig cfg;
    public DocumentScanner(Context c,JobStore store){this.c=c;this.store=store;this.cfg=new AppConfig(c);}

    private static final class Dir { Uri children; int depth; Dir(Uri u,int d){children=u;depth=d;} }

    public Result scan(boolean historical) {
        Result r=new Result(); String s=cfg.sourceTree(); if(s.isEmpty()){r.note="녹음폴더 미선택";return r;}
        Uri tree=Uri.parse(s); ContentResolver cr=c.getContentResolver();
        String rootId=DocumentsContract.getTreeDocumentId(tree);
        ArrayDeque<Dir> q=new ArrayDeque<>(); q.add(new Dir(DocumentsContract.buildChildDocumentsUriUsingTree(tree,rootId),0));
        long previous=cfg.lastScanMs(), since=historical?cfg.rangeStartMs():Math.max(0,previous-LOOKBACK), until=historical?cfg.rangeEndMs():Long.MAX_VALUE;
        String[] proj={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED};
        while(!q.isEmpty() && r.visited<MAX_DOCS) {
            Dir d=q.removeFirst();
            try(Cursor cur=cr.query(d.children,proj,null,null,null)) {
                if(cur==null) continue;
                while(cur.moveToNext() && r.visited<MAX_DOCS) {
                    r.visited++; String id=cur.getString(0), name=cur.getString(1), mime=cur.getString(2); long size=cur.isNull(3)?0:cur.getLong(3), mod=cur.isNull(4)?0:cur.getLong(4);
                    Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,id);
                    if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                        // Do not recurse indefinitely. Providers that supply directory timestamps let us skip stale subtrees.
                        if(d.depth<MAX_DEPTH && (d.depth==0 || historical || mod==0 || mod>=since)) q.addLast(new Dir(DocumentsContract.buildChildDocumentsUriUsingTree(tree,id),d.depth+1));
                    } else if(isAudio(name,mime) && (mod==0 || (mod>=since && mod<=until))) {
                        String contact=contactHint(name); store.upsertDiscovered(doc.toString(),name==null?"recording":name,size,mod,mod,contact); r.discovered++;
                    }
                }
            } catch(SecurityException se){r.note="폴더 읽기 권한이 없습니다";break;} catch(Throwable t){r.note="폴더 확인 오류: "+t.getClass().getSimpleName();}
        }
        if(r.visited>=MAX_DOCS){r.truncated=true;r.note="한 번에 "+MAX_DOCS+"개까지만 확인함";}
        if(!historical) cfg.setLastScanMs(System.currentTimeMillis());
        return r;
    }
    private boolean isAudio(String name,String mime){ if(mime!=null&&mime.startsWith("audio/"))return true; String n=name==null?"":name.toLowerCase(Locale.ROOT); return n.endsWith(".m4a")||n.endsWith(".aac")||n.endsWith(".mp3")||n.endsWith(".wav")||n.endsWith(".amr")||n.endsWith(".3gp")||n.endsWith(".ogg")||n.endsWith(".mp4"); }
    private String contactHint(String n){ if(n==null)return ""; String x=n.replaceAll("\\.[^.]+$","").replaceAll("[_-]+"," ").trim(); return x.length()>48?x.substring(0,48):x; }
}
