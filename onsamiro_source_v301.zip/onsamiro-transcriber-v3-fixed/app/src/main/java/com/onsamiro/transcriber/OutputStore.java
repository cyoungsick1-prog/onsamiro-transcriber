package com.onsamiro.transcriber;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class OutputStore {
    private final Context c; private final AppConfig cfg;
    public OutputStore(Context c){this.c=c;cfg=new AppConfig(c);}

    public String writeDraft(JobRecord j,String text,QualityGuard.Result q)throws Exception{
        File d=new File(c.getFilesDir(),"review");if(!d.exists())d.mkdirs();File f=new File(d,"job_"+j.id+".review.txt");try(FileOutputStream o=new FileOutputStream(f,false)){o.write(render(j,text,q).getBytes(StandardCharsets.UTF_8));o.getFD().sync();}return f.getAbsolutePath();
    }

    public String writeFinalNoOverwrite(JobRecord j,String text,QualityGuard.Result q)throws Exception{
        if(cfg.outputTree().isEmpty())throw new IllegalStateException("TXT 저장폴더 미선택");Uri tree=Uri.parse(cfg.outputTree());String rootId=DocumentsContract.getTreeDocumentId(tree);Uri parent=DocumentsContract.buildDocumentUriUsingTree(tree,rootId);Set<String> names=listNames(tree,rootId);
        String base=safeBase(j.displayName)+"_전사";String name=base+".txt";if(names.contains(name)){String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.KOREA).format(new Date());name=base+"_재검사_"+stamp+".txt";}
        Uri out=DocumentsContract.createDocument(c.getContentResolver(),parent,"text/plain",name);if(out==null)throw new IllegalStateException("최종 TXT 생성 실패");try(OutputStream os=c.getContentResolver().openOutputStream(out,"w")){if(os==null)throw new IllegalStateException("최종 TXT 쓰기 실패");os.write(render(j,text,q).getBytes(StandardCharsets.UTF_8));os.flush();}return out.toString();
    }

    private Set<String> listNames(Uri tree,String rootId){Set<String> s=new HashSet<>();Uri u=DocumentsContract.buildChildDocumentsUriUsingTree(tree,rootId);try(Cursor c0=c.getContentResolver().query(u,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){if(c0!=null)while(c0.moveToNext())s.add(c0.getString(0));}catch(Throwable ignored){}return s;}
    private String render(JobRecord j,String text,QualityGuard.Result q){return "온새미로 통화전사\n원본: "+j.displayName+"\n통화시각: "+new Date(j.callTimeMs)+"\n원본길이(ms): "+j.durationMs+"\n처리구간: "+j.doneSegments+"/"+j.totalSegments+"\n품질상태: "+q.verdict+"\n품질근거: "+q.reasonText()+"\n\n"+text.trim()+"\n";}
    private String safeBase(String n){String x=n==null?"통화":n.replaceAll("\\.[^.]+$","").replaceAll("[\\\\/:*?\"<>|]","_");return x.length()>80?x.substring(0,80):x;}
}
