#!/usr/bin/env bash
set -euo pipefail
APK="${1:-}"
[[ -f "$APK" ]] || { echo "APK missing: $APK" >&2; exit 2; }
BT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}/build-tools/35.0.0"
[[ -x "$BT/apksigner" ]] || { echo "apksigner missing" >&2; exit 3; }
[[ -x "$BT/zipalign" ]] || { echo "zipalign missing" >&2; exit 3; }
"$BT/apksigner" verify --verbose "$APK"
"$BT/zipalign" -c -P 16 -v 4 "$APK"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
unzip -q "$APK" 'lib/*/*.so' -d "$TMP"
count=0
while IFS= read -r -d '' so; do
  count=$((count+1))
  echo "checking $so"
  readelf -lW "$so" | awk '
    $1=="LOAD" {
      a=$NF; sub(/^0x/,"",a); v=("0x" a)+0;
      if (v < 16384) { print "FAIL: PT_LOAD alignment < 16KiB: "$0 > "/dev/stderr"; bad=1 }
    }
    END { exit bad?1:0 }
  '
done < <(find "$TMP/lib" -type f -name '*.so' -print0)
[[ $count -gt 0 ]] || { echo "No native libraries found" >&2; exit 4; }
echo "APK_VERIFY PASS ($count native libraries)"
