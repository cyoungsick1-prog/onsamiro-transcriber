# 검증 상태

## 확인됨
- 사용자 제공 v2.2.7 APK SHA-256: `ad1e425ef4a3978acf6f5f152fcf40cb3e36aacca8cbc7fdf2af2e56d1b0ece6`.
- v2.2.7 APK에는 `arm64-v8a` native library만 포함.
- `libonsamiro_core.so`에서 `WhisperBridge_nativeCreate/nativeTranscribe/nativeFree` JNI export 확인. 로컬 Whisper native 전사 구조임.
- 과거 '소스및검증.zip'에는 Android Java/Kotlin/C++ 원본 소스가 없고 APK 패치/서명 Python 스크립트와 검증로그만 있음.
- 기존 `libonsamiro_core.so` PT_LOAD p_align은 `0x1000`; 다른 포함 native library는 `0x4000`. 16 KiB page 기기라면 core 라이브러리 로딩 문제가 생길 수 있는 **코드 수준의 강한 원인 후보**다. 사용자의 실제 PAGE_SIZE/linker crash 로그가 없어서 확정 원인으로 닫지는 않음.
- 새 재구현 소스에는 prebuilt `.so`, 서명키, 비밀번호가 포함되지 않음.
- 새 소스 manifest는 접근성/오버레이/SMS/통화기록/모든파일 권한을 요청하지 않음.
- `QualityGuardSelfTest` 5개 케이스 PASS:
  1. 90초 통화 + `음 아 안녕하세요` => REVIEW_REQUIRED
  2. 실제 무음에 가까운 입력 => NO_AUDIO
  3. 긴 통화 일부 구간 실패 => PARTIAL
  4. 7초 짧은 정상통화 => PASS
  5. 충분한 70초 상담 전사 => PASS
- `scripts/static_audit.sh`로 민감권한/cleartext/16KiB 설정/prebuilt native/key 유입 여부 검사 가능.

## 미실시 / 미확정
- Android Gradle 빌드: 미실시. 현재 실행환경에 Android SDK, Build Tools, Gradle, CMake Android toolchain이 없음.
- APK 생성/서명: 미실시.
- 에뮬레이터 설치/반복 실행: 미실시.
- 사용자 삼성폰 새 설치/권한 허용·거부/폴더·모델 없음: 미실시.
- 실제 짧은 통화/긴 통화 끝부분/무음/부분실패/저장실패: 미실시.
- 앱 재시작·재부팅·주기 변경·중복 실행/유휴 CPU·배터리: 미실시.
- 삼성 '안전하지 않은 앱' 경고 재검사: 미실시. 정확한 검사 주체/탐지 사유도 미확정.

## 다음 원인 확정에 필요한 최소 기기 자료

PC에 ADB가 있는 경우 딱 한 번 아래를 실행한다.

```bash
adb shell getconf PAGE_SIZE
adb shell getprop ro.product.cpu.abi
adb logcat -c
# 폰에서 앱 실행 → 종료 오류 1회 재현
adb logcat -d AndroidRuntime:E linker:E DEBUG:E '*:S' > onsamiro_crash.txt
```

`onsamiro_crash.txt`에서 전화번호/파일명 같은 개인정보가 보이면 해당 문자열만 `***`로 바꿔 전달하면 된다. stack trace의 클래스명, `dlopen`, `UnsatisfiedLinkError`, `SIGSEGV` 줄은 남겨야 원인 판별이 가능하다.
