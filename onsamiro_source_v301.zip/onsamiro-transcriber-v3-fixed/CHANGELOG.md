# v3.0.0-rebuild 변경내역

- 기존 APK/Dex 바이너리 패치 방식을 폐기하고 원본 Android 프로젝트 형태로 재구현.
- package/applicationId `com.onsamiro.transcriber` 유지. 구버전이 없어도 새 설치 가능한 구조.
- 녹음폴더/최종 TXT 폴더/Whisper 모델을 최초 실행에서 각각 선택.
- 추천 모델 다운로드는 `.part`로 받은 뒤 Whisper 실제 로드 확인 후 원자적으로 교체.
- 30분/1시간/2시간/4시간 주기 선택, 기본 2시간.
- JobScheduler 기반 주기 작업. Android 절전 정책 때문에 정확한 시각 실행을 보장하지 않음.
- ContentObserver 기반 실시간 감시는 공급자가 변경 이벤트를 주는 경우에만 즉시 반응. 주기 스캔이 보조 경로.
- 수동 목록 확인, 수동 전사, 일시정지/재개, 자동실행 끄기, 실패/확인필요 재시도, 개별 재시도/제외.
- Wi‑Fi 전용/충전 중/배터리 낮음 대기 제약과 대기 사유 표시.
- SQLite 작업/구간 상태 영속화. 중단 후 완료 구간은 재처리하지 않음.
- 180초 구간 단위 전사. 구간 결과를 즉시 DB에 저장. 실패 구간은 제한 재시도 후 PARTIAL 유지.
- 품질검사는 글자수 한 항목이 아니라 원본 길이, 디코딩 범위, 마지막 처리 위치, 음성비율, 전사 분량, 의미 단어, 반복도를 함께 사용.
- 실제 무음은 `NO_AUDIO`, 의심 결과는 `REVIEW_REQUIRED`, 일부 실패는 `PARTIAL`.
- 품질검사 전 결과는 내부 review draft. 정상 PASS만 사용자 선택 폴더에 최종 TXT 신규 생성. 기존 TXT 덮어쓰기 없음.
- 과거 TXT는 최대 200건의 빠른 의심 검사만 제공하며 자동 재전사하지 않음.
- native Whisper는 whisper.cpp v1.9.4 소스에서 다시 빌드하도록 구성하고 16 KiB page-size linker 옵션 추가.

## 3.0.1-rebuild (2026-09-21)
- Added ACCESS_NETWORK_STATE for Wi-Fi-only runtime checks.
- Setup readiness now requires persisted write permission for the TXT output tree.
- Fixed manual retry so REVIEW_REQUIRED/completed segment state actually re-runs audio segments.
- Fixed batch retry so review-required jobs re-run all segments and failed jobs re-run failed segments.
- Boot/package replacement now restores realtime monitoring on a best-effort basis after rescheduling periodic work.
- Added reproducible CI build, API 35 emulator smoke test, APK signature/ZIP/16 KiB PT_LOAD alignment gates, and SHA-256 artifact output.
