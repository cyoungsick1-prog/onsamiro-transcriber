# 빌드 방법

이 프로젝트는 **기존 APK를 패치하는 프로젝트가 아니라 새로 재구현한 Android 소스 프로젝트**다.

## 요구 환경
- Android Studio 또는 Android SDK command-line tools
- JDK 17 이상
- Android SDK Platform 35
- Android Build Tools 35.x
- NDK 28.0.13004108
- CMake 3.22.1 이상
- Gradle 8.x + Android Gradle Plugin 8.7.3
- Git

## Whisper 소스 준비

```bash
./scripts/fetch_whisper.sh
```

whisper.cpp v1.9.4의 commit `927cfce34f31707e17f2bff35c349632fb9e2c3a`에 고정한다.

## 빌드

Android Studio에서 프로젝트를 열고 SDK/NDK 설치 후 `assembleDebug` 또는 `assembleRelease`를 실행한다.
CLI 예시는 로컬 Gradle이 설치돼 있을 때:

```bash
gradle :app:assembleDebug
```

이 소스 묶음에는 서명키가 없다. release 배포 시 개인 서명키는 소스/배포 ZIP 밖에서 관리한다.

## 16 KiB page size

기존 APK의 `libonsamiro_core.so`는 ELF PT_LOAD 정렬이 0x1000이었다. 새 JNI 라이브러리는 CMake에서 16 KiB 링크 정렬 플래그를 지정하고, NDK 28의 flexible page size 옵션을 사용하도록 구성했다. 실제 생성된 `.so`의 PT_LOAD 정렬은 빌드 후 `readelf -lW`로 다시 확인해야 한다.
