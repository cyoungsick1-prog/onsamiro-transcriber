# Build status — 2026-09-21

## Completed in the Chat execution environment
- Source static audit: PASS
- QualityGuard JVM self-test: PASS
- Concrete source fixes applied for network-state permission, SAF output write permission, retry semantics, and reboot realtime restore.
- CI recipe added for AGP 8.7.3 + Gradle 8.9 + JDK 17 + SDK 35 + NDK 28.0.13004108 + CMake 3.22.1.
- CI gate added for apksigner, zipalign 16 KiB check, ELF PT_LOAD alignment, SHA-256, and API 35 emulator launch/relaunch with notification permission denied/allowed.

## Not executed in this container
This container does not contain Android SDK/Gradle/aapt2/d8/apksigner/zipalign/adb/emulator, and outbound package downloads are unavailable. Therefore an APK built from this corrected source has NOT been produced or claimed here.

The next executable step is to run `.github/workflows/android-build.yml` in a GitHub repository with Actions enabled, or build on a machine with the toolchain above.
