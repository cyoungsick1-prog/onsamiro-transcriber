`./scripts/fetch_whisper.sh`를 실행하면 여기에 whisper.cpp v1.9.4 고정 소스가 내려온다.
이 전달 ZIP에는 제3자 전체 소스를 중복 포함하지 않는다.
